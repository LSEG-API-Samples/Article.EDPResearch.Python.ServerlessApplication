import sys
sys.path.append('./modules')
import requests
import json, time
import boto3

#
# Application Constants
EDP_version = "/beta1"
base_URL = "https://api.refinitiv.com"
category_URL = "/auth/oauth2"
endpoint_URL = "/token"
CLIENT_SECRET = ""
SCOPE = "trapi"


TOKEN_ENDPOINT = base_URL + category_URL + EDP_version + endpoint_URL
def lambda_handler(event, context):
	client = boto3.client('ssm')
	response = client.get_parameters(
	    Names=['EDPUsername','EDPPassword','EDPClientId'],
	    WithDecryption=False
	)
	
	params = response['Parameters']
	username = list(filter(lambda x : x['Name'] == 'EDPUsername', params))[0]['Value']
	password = list(filter(lambda x : x['Name'] == 'EDPPassword', params))[0]['Value']
	clientId = list(filter(lambda x : x['Name'] == 'EDPClientId', params))[0]['Value']

	tData = {
	"username": username,
	"password": password,
	"grant_type": "password",
	"scope": SCOPE,
	"takeExclusiveSignOnControl": "true"
	};
	
	# Make a REST call to get latest access token
	response = requests.post(
		TOKEN_ENDPOINT,
		headers = {
			"Accept": "application/json"
		},
		data = tData,
		auth = (
			clientId,
			CLIENT_SECRET
		)
	)

	if response.status_code != 200:
		raise Exception("Failed to get access token {0} - {1}".format(response.status_code, response.text));

	output = json.loads(response.text)
	
	response = client.put_parameter(
    Name='EDPAccessToken',
    Value= output['access_token'],
    Type='String',
    Overwrite=True)
    
	response = client.put_parameter(
    Name='EDPRefreshToken',
    Value= output['refresh_token'],
    Type='String',
    Overwrite=True)

	return {
	}
