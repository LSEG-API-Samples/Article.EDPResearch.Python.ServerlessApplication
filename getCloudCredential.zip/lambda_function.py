import json
import atexit
import sys
import boto3
from botocore.exceptions import ClientError
import sys
sys.path.append('./modules')
import requests

# Application Constants
base_URL = "https://api.refinitiv.com"
EDP_version = "/v1"

def lambda_handler(event, context):
    client = boto3.client('ssm')
    response = client.get_parameter(
        Name='EDPAccessToken',
        WithDecryption=False
    )
    accessToken = response['Parameter']['Value']
	
    category_URL = "/auth/cloud-credentials"
    endpoint_URL = "/"
    RESOURCE_ENDPOINT = base_URL + category_URL + EDP_version + endpoint_URL
    requestData = {
        "endpoint": event['endpoint']
    }
	
    dResp = requests.get(RESOURCE_ENDPOINT, headers = {"Authorization": "Bearer " + accessToken}, params = requestData);
    if dResp.status_code != 200:
        raise ValueError("Unable to get credentials. Code %s, Message: %s" % (dResp.status_code, dResp.text))
    else:
        jResp = json.loads(dResp.text)
        return {
            'accessKeyId': jResp["credentials"]["accessKeyId"],
            'secretKey': jResp["credentials"]["secretKey"],
            'sessionToken': jResp["credentials"]["sessionToken"]
        }