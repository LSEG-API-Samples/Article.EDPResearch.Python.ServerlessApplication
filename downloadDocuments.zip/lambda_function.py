
import json
import boto3
import sys
sys.path.append('./modules')
import requests

# Application Constants
base_URL = "https://api.refinitiv.com"
category_URL = "/data/research/v1"
endpoint_URL = "/documents/"
document_URL = base_URL+category_URL+endpoint_URL;
	
#=============================================================================
def downloadDocument(id,docUrl,outputBucket):
	s3 = boto3.client('s3')	
	response = requests.get(docUrl, stream=True)
	print(response.raw)
	s3.upload_fileobj(response.raw, outputBucket, id+".txt")

#=============================================================================
def getDocumentUrl(token,docID,uId):
	document_type = "/text"
	
	p = {'uuid': uId}
	
	RESOURCE_ENDPOINT = document_URL + docID + document_type

	# get the latest access token
	accessToken = token
	hdrs = {
		"Authorization": "Bearer " + accessToken,
		"Content-Type": "application/json"
	};

	dResp = requests.get(RESOURCE_ENDPOINT, headers = hdrs, params=p);
	if dResp.status_code != 200:
		raise ValueError("Unable to subscribe. Code %s, Message: %s" % (dResp.status_code, dResp.text))
	else:
		jResp = json.loads(dResp.text)
		return(jResp['signedUrl'])

#=============================================================================
def lambda_handler(event, context):
    doc = event
    client = boto3.client('ssm')
    response = client.get_parameters(
        Names=['EDPAccessToken','UUID','BucketStorage'],
        WithDecryption=False
    )
    
    params = response['Parameters']
    bucket = list(filter(lambda x : x['Name'] == 'BucketStorage', params))[0]['Value']
    token = list(filter(lambda x : x['Name'] == 'EDPAccessToken', params))[0]['Value']
    uid = list(filter(lambda x : x['Name'] == 'UUID', params))[0]['Value']
    
    docUrl = getDocumentUrl(token,doc,uid)
    downloadDocument(doc,docUrl,bucket)
        
    return {
        'statusCode': 200
    }