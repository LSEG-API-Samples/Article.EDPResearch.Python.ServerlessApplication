import boto3
import json
import base64
import html
import sys
from botocore.exceptions import ClientError
sys.path.insert(0, "./modules")
from Crypto.Cipher import AES
import requests

REGION = 'us-east-1'

#=============================================================================
def decrypt(key, source):
	GCM_AAD_LENGTH = 16
	GCM_TAG_LENGTH = 16
	GCM_NONCE_LENGTH = 12
	key = base64.b64decode(key)
	cipherText = base64.b64decode(source)
	
	aad = cipherText[:GCM_AAD_LENGTH]
	nonce = aad[-GCM_NONCE_LENGTH:] 
	tag = cipherText[-GCM_TAG_LENGTH:]
	encMessage = cipherText[GCM_AAD_LENGTH:-GCM_TAG_LENGTH]
	
	cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
	cipher.update(aad)
	decMessage = cipher.decrypt_and_verify(encMessage, tag)
	return decMessage

#=============================================================================
def lambda_handler(event, context):
    # create a SQS session
	session = boto3.Session(
		aws_access_key_id = event['accessKeyId'],
		aws_secret_access_key = event['secretKey'],
		aws_session_token = event['sessionToken'],
		region_name = REGION
	)
	
	cryptographyKey = event['cryptographyKey']
	endpoint = event['endpoint']
	
	sqs = session.client('sqs')

	print('Polling messages from queue...')
	try:
		resp = sqs.receive_message(QueueUrl = endpoint, WaitTimeSeconds = 1, MaxNumberOfMessages=10)
	except ClientError as e:
		if e.response['Error']['Code'] == 'ExpiredToken':
			return {
			'status': 'ExpiredToken'
			}
		else:
			return {
				'status': 'Queue Failed'
			}

	docIdList= []
	if 'Messages' in resp:
		messages = resp['Messages']
		# print and remove all the nested messages
		for message in messages:
			mBody = message['Body']
			# decrypt this message
			m = decrypt(cryptographyKey, mBody)
			
			jsMessage = json.loads(m);
			docID = jsMessage['payload']['docID']
			fileSize = int(jsMessage['payload']['fileSize'])
			
			# in case that the file is too big, function can verify size of document
			#if fileSize < 1000000:
			#	docIdList.append(str(docID))
			
			docIdList.append(str(docID))
			
			# *** accumulate and remove all the nested message
			sqs.delete_message(QueueUrl = endpoint, ReceiptHandle = message['ReceiptHandle'])
		
		seperator = ', '
		print("document Ids: "+ seperator.join(docIdList))
	if len(docIdList)>0:
		return {
			'status': 'Doc Available',
			'docIds': json.dumps(docIdList)
		}		
	else:
		return {
			'status': 'None'
		}
