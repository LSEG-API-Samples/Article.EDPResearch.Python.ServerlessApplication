import json
import atexit
import boto3
import sys
import sys
sys.path.append('./modules')
import requests
from botocore.exceptions import ClientError

# Application Constants
base_URL = "https://api.refinitiv.com"
EDP_version = "/beta1"

def unsubResearch(accessToken):
	category_URL = "/alerts"
	endpoint_URL = "/research-subscriptions"
	RESOURCE_ENDPOINT = base_URL + category_URL + EDP_version + endpoint_URL

	hdrs = {
		"Authorization": "Bearer " + accessToken,
		"Content-Type": "application/json"
	};
	
	dResp = requests.delete(RESOURCE_ENDPOINT, headers = hdrs);
	if dResp.status_code != 204:
		raise ValueError("Unable to subscribe. Code %s, Message: %s" % (dResp.status_code, dResp.text))

def lambda_handler(event, context):
	client = boto3.client('ssm')
	response = client.get_parameters(
	    Names=['EDPAccessToken','UUID'],
	    WithDecryption=False
	)
	
	params = response['Parameters']
	accessToken = list(filter(lambda x : x['Name'] == 'EDPAccessToken', params))[0]['Value']
	uuid = list(filter(lambda x : x['Name'] == 'UUID', params))[0]['Value']
	
	# unsubscribe Research alert first.
	unsubResearch(accessToken)
	
	category_URL = "/alerts"
	endpoint_URL = "/research-subscriptions"
	RESOURCE_ENDPOINT = base_URL + category_URL + EDP_version + endpoint_URL
	requestData = {
		"transport": {
			"transportType": "AWS-SQS"
		},
		"userID": uuid
	}
	
	hdrs = {
		"Authorization": "Bearer " + accessToken,
		"Content-Type": "application/json"
	};
	
	dResp = requests.post(RESOURCE_ENDPOINT, headers = hdrs, data = json.dumps(requestData));
	if dResp.status_code != 200:
		raise ValueError("Unable to subscribe. Code %s, Message: %s" % (dResp.status_code, dResp.text))
	
	pResp = dResp.json()
	return {
		'endpoint': pResp["transportInfo"]["endpoint"],
		'cryptographyKey': pResp["transportInfo"]["cryptographyKey"],
		'subsriptionID': pResp["subscriptionID"]
	}