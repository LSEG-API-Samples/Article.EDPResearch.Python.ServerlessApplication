import json
import boto3
from datetime import datetime  
from datetime import timedelta
import sys
sys.path.append('./modules')
import requests

# Application Constants
EDP_version = "/v1"
base_URL = "https://api.refinitiv.com"
category_URL = "/auth/oauth2"
endpoint_URL = "/token"
CLIENT_SECRET = ""
SCOPE = "trapi"


TOKEN_ENDPOINT = base_URL + category_URL + EDP_version + endpoint_URL

#=============================================================================
def _requestNewToken(username,clientId,refreshToken):
	client = boto3.client('ssm')
	tData = {
		"refresh_token": refreshToken,
		"username": username,
		"grant_type": "refresh_token",
	};

	# Make a REST call to get latest access token
	res = requests.post(
		TOKEN_ENDPOINT,
		headers = {
			"Accept": "application/json"
		},
		data = tData,
		auth = (
			clientId,
			CLIENT_SECRET
		)
	)

	if res.status_code != 200:
		raise Exception("Failed to get access token {0} - {1}".format(res.status_code, res.text));
	
	res = json.loads(res.text)
	
	response = client.put_parameter(
	Name='EDPAccessToken',
	Value= res['access_token'],
	Type='String',
	Overwrite=True)
	
	# Return the new token
	return res['access_token'];

#=============================================================================
def lambda_handler(event, context):
    
    docIdList = json.loads(event['docIds'])

    client = boto3.client('ssm')
    response = client.get_parameters(
        Names=['EDPUsername','EDPClientId','UUID','EDPAccessToken','EDPRefreshToken'],
        WithDecryption=False
    )
    
    params = response['Parameters']
    usename = list(filter(lambda x : x['Name'] == 'EDPUsername', params))[0]['Value']
    clientId = list(filter(lambda x : x['Name'] == 'EDPClientId', params))[0]['Value']
    uid = list(filter(lambda x : x['Name'] == 'UUID', params))[0]['Value']
    token = list(filter(lambda x : x['Name'] == 'EDPAccessToken', params))[0]['Value']
    token_lastModifiedDate = list(filter(lambda x : x['Name'] == 'EDPAccessToken', params))[0]['LastModifiedDate']
    refresh_token = list(filter(lambda x : x['Name'] == 'EDPRefreshToken', params))[0]['Value']

    token_expiredTime = token_lastModifiedDate + timedelta(seconds=270)
    if token_expiredTime.time() < datetime.now().time():
    	#Expired
    	token = _requestNewToken(usename,clientId,refresh_token)
    
    return {
        'statusCode': 200
    }
